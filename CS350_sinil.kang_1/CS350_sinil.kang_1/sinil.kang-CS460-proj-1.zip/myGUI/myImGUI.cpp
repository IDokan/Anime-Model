/* Start Header -------------------------------------------------------
Copyright (C) FALL2021 DigiPen Institute of Technology.
Reproduction or disclosure of this file or its contents without the prior written
consent of DigiPen Institute of Technology is prohibited.
File Name: myImGUI.cpp
Purpose: myImGUI implementation!
Language: C++
Platform: Windows SDK version: 10.0.19041.0, OS: Windows 10. GPU: NVIDIA GeForce840M. OpenGL Driver version: 10.18.15.4279, 8-24-2015
Project: sinil.kang_CS300_1
Author: Sinil Kang = sinil.kang = Colleague ID: 0052782
Creation date: 10/20/2021
End Header --------------------------------------------------------*/

#pragma once

#define _CRT_SECURE_NO_WARNINGS

#include <iostream>
#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <../myGUI/imgui.h>
#include <../myGUI/imgui_impl_opengl3.h>
#include <../myGUI/imgui_impl_glfw.h>

#include <../myGUI/myImGUI.h>
#include <../Common/Lights/LightManager.h>

#include <string>
#include <../Common/Meshes/MyObjReader.h>
#include <../Common/Meshes/Mesh.h>
#include <../Common/Meshes/MyMeshes/ObjectMesh.h>
#include <glm/gtx/transform.hpp>
#include "../Common/Utility/Timer.h"

namespace MyImGUI {
    bool* showSkeletonFlag;
    bool* playAnimation;
    float* animationTime;
    float maxAnimationTime = 10.f;
    bool* showSimpleMesh;
    float maxSimpleAnimationTime = 10.f;

    std::string fpsData = "FPS: -1";

    namespace Helper
    {
        void BasicInformation();
        void Normals();
        void Animation();
        void Models();

        // Helper to display a little (?) mark which shows a tooltip when hovered.
        // In your own code you may want to display an actual icon if you are using a merged icon fonts (see docs/FONTS.md)
        void HelpMarker(const char* desc);
    }
}



void MyImGUI::Helper::HelpMarker(const char* desc)
{
    ImGui::SameLine();
    ImGui::TextDisabled("(?)");
    if (ImGui::IsItemHovered())
    {
        ImGui::BeginTooltip();
        ImGui::PushTextWrapPos(ImGui::GetFontSize() * 35.0f);
        ImGui::TextUnformatted(desc);
        ImGui::PopTextWrapPos();
        ImGui::EndTooltip();
    }
}


void MyImGUI::InitImGUI(GLFWwindow* window)
{
    // Setup Dear ImGui context
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();

    // Setup Platform/Renderer bindings
    ImGui_ImplGlfw_InitForOpenGL(window, true);
    ImGui_ImplOpenGL3_Init("#version 410");

    // Setup Dear ImGui style
    ImGui::StyleColorsDark();
}

void MyImGUI::UpdateImGUI()
{
    glfwPollEvents();
    glClearColor(0.45f, 0.55f, 0.6f, 1.f);
    glClear(GL_COLOR_BUFFER_BIT);

    ImGui_ImplOpenGL3_NewFrame();
    ImGui_ImplGlfw_NewFrame();
    ImGui::NewFrame();

    ImGui::Begin("Controller");

    Helper::BasicInformation();
    Helper::Normals();
    Helper::Animation();
    Helper::Models();

    ImGui::End();
    ImGui::Render();
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
}

void MyImGUI::ClearImGUI()
{
    ImGui_ImplOpenGL3_Shutdown();
    ImGui_ImplGlfw_Shutdown();
    ImGui::DestroyContext();
}

void MyImGUI::SetNormalDisplayReferences(bool* _showSkeletonFlag)
{
    showSkeletonFlag = _showSkeletonFlag;
}

void MyImGUI::SetAnimationReferences(bool* _playAnimation, float* _animationTime, float _maxAnimationTime, bool* _showSimpleMesh, float _maxSimpleAnimationTime)
{
    playAnimation = _playAnimation;
    animationTime = _animationTime;
    maxAnimationTime = _maxAnimationTime;
    showSimpleMesh = _showSimpleMesh;
    maxSimpleAnimationTime = _maxSimpleAnimationTime;
}

void MyImGUI::Helper::BasicInformation()
{
    if (ImGui::CollapsingHeader("Basic Information", ImGuiTreeNodeFlags_::ImGuiTreeNodeFlags_DefaultOpen))
    {
        Timer* timer = Timer::GetTimer();
        int frame = timer->GetFPSFrame();

        if (frame > 0)
        {
            char buf[32];
            _itoa_s(frame, buf, 10);
            fpsData = std::string("FPS: ") + std::string(buf);
        }

        ImGui::Text(fpsData.c_str());

        ImGui::Text("How to move camera:");
        ImGui::Text("\tWASD to move camera.\n\tDuring move, press left shift to move faster.\n\tPress right mouse button to look around.\n\tPress E to move up\n\tPress Q to move down");
    }
}

void MyImGUI::Helper::Normals()
{
    if (ImGui::CollapsingHeader("Skeleton"))
    {
        ImGui::Checkbox("Display skeleton", showSkeletonFlag);
    }
}

void MyImGUI::Helper::Animation()
{
    if (ImGui::CollapsingHeader("Animation"))
    {
        ImGui::Checkbox("Play Animation", playAnimation);
        if (*playAnimation == false)
        {
            if (*showSimpleMesh == true)
            {
                ImGui::SliderFloat("Animation Time", animationTime, 0.f, maxSimpleAnimationTime);
            }
            else
            {
                ImGui::SliderFloat("Animation Time", animationTime, 0.f, maxAnimationTime);
            }
        }
    }
}

void MyImGUI::Helper::Models()
{
    if (ImGui::CollapsingHeader("Model"))
    {
        ImGui::Checkbox("Show simple model", showSimpleMesh);
    }
}
